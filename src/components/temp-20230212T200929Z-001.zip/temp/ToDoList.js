import React from 'react'
import { useSelector } from 'react-redux'
import ShowTask from './ShowTask'

function ToDoList() {
  const list = useSelector((state)=> state.todolist);

    const renderList = list.map((item) => {
        return <ShowTask key={item.id} item={item} />
    })
  return (
    <div>
        {renderList}
    </div>
  )
}

export default ToDoList